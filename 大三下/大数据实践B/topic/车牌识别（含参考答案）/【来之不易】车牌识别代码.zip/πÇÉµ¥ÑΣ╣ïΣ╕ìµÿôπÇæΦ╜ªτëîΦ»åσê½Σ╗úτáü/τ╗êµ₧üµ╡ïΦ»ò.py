import cv2
import tensorflow as tf
import os
import shutil
import numpy as np
from preprocess import plate_detected  # 车牌识别
from plate_seg import charser_cut  # 车牌分割
from cnn_net2 import CnnNet  # 模型预测
from myfun import get_img_lab  # 文件读取

# 定义参数
provinces = ["皖", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑", "苏", "浙", "京", "闽", "赣",
             "鲁", "豫", "鄂", "湘", "粤", "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁",
             "新", "警", "学", "O"]
ads = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M',
       'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
       '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'O']

img_path = './data/0034-0_1-270&523_365&553-364&553_270&553_271&523_365&523-0_0_10_23_24_32_33-90-17.jpg'
img = cv2.imread(img_path)
img_name = os.path.basename(img_path)
plate_path = './test/'  # 车牌保存的路径
if not os.path.exists(plate_path):
    os.makedirs(plate_path)
file_path = './test/char'  # 车牌字符保存的路径
shutil.rmtree(file_path)  # 删除文件夹
os.makedirs(file_path)  # 新建文件夹

# 车牌识别与保存
char_set = img_name.split('-')[4].split('-')  # 车牌字符
PD = plate_detected()
PD.img_save_path = plate_path   # 更新车牌图片存储的路径
# PD.file_path = './data'
PD.detect(img_name)

# 车牌字符的分割
CC = charser_cut()
CC.plate_path = plate_path  # 车牌路径
CC.char_save_path = file_path  # 字符存储路径
tmp = [i for i in os.listdir(plate_path) if os.path.isfile(os.path.join(plate_path, i))]
tmp.sort(key=lambda x: os.path.getmtime(os.path.join(CC.plate_path, x)))
CC.plate_seg(tmp[-1])

# 字符识别
imgs, labs, num2str = get_img_lab(file_path)
res = ''
for part in [1, 2]:
    cnn = CnnNet(output_size=num2str[part])
    y_pre_prob, y_pre_lab = cnn.predict(imgs[part], part)
    res = res + ''.join([num2str[part][i] for i in y_pre_lab])
print(res)
cv2.imshow(res, img)
cv2.waitKey(0)

