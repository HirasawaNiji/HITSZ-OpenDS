'''
Version 4.0 2020年7月17日18:59:14
'''
#%% 加载相关库
import os
import cv2
import numpy as np
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.pyplot as plt
from myfun import Gamma_trans
import time

class charser_cut():
    def __init__(self):
        self.provinces = ["皖", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑", "苏", "浙", "京", "闽", "赣",
                          "鲁", "豫", "鄂", "湘", "粤", "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁",
                          "新", "警", "学", "O"]
        self.ads = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M',
                    'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'O']
        self.plate_path = './plate'  # plate_path: 车牌图片路径
        self.char_save_path = './cut_char/'

    def rotate_bound(self, image, angle):
        ## 图片旋转
        # 获取宽高
        (h, w) = image.shape[:2]
        (cX, cY) = (w // 2, h // 2)

        # 提取旋转矩阵 sin cos
        M = cv2.getRotationMatrix2D((cX, cY), -angle, 1.0)
        cos = np.abs(M[0, 0])
        sin = np.abs(M[0, 1])

        # 计算图像的新边界尺寸
        nW = int((h * sin) + (w * cos))
        nH = h

        # 调整旋转矩阵
        M[0, 2] += (nW / 2) - cX
        M[1, 2] += (nH / 2) - cY

        return cv2.warpAffine(image, M, (nW, nH), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

    def get_minAreaRect(self, image):  ## 获取图片旋转角度
        gray = cv2.bitwise_not(image)
        thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
        coords = np.column_stack(np.where(thresh > 0))
        return cv2.minAreaRect(coords)

    def show_gray(self, img):
        # 展示单通道图片
        plt.imshow(img, cmap='gray')
        plt.show()

    def draw_bar(self, gray_img):
        '''绘制频率直方图和图像组合图'''
        x_histogram = np.count_nonzero(255 - gray_img, axis=1)
        y_histogram = np.count_nonzero(255 - gray_img, axis=0)
        fig, ax = plt.subplots(figsize=(8, 8))
        m, n = gray_img.shape
        # the scatter plot:
        ax.imshow(gray_img, cmap='gray')
        ax.axis('off')
        ax.set_xlim(0, n)
        ax.set_ylim(0, m)
        ax.set_aspect(1.)  # 设置主轴的长宽比。
        divider = make_axes_locatable(ax)  # # 在当前轴的右侧和顶部创建新轴
        # 高度和垫下面的英寸
        ax_histx = divider.append_axes("top", 1.2, pad=0., sharex=ax)
        ax_histy = divider.append_axes("right", 1.2, pad=0., sharey=ax)

        # make some labels invisible
        ax_histx.xaxis.set_tick_params(labelbottom=False)
        ax_histy.yaxis.set_tick_params(labelleft=False)

        ax_histx.bar(range(len(y_histogram)), y_histogram, width=1, align='edge')
        ax_histy.barh(range(len(x_histogram)), x_histogram, height=1, align='edge')

        plt.show()

    def plate_seg(self, name):
        # name: 车牌图片的名称

        card_char = name.replace('.jpg', '').split('_')[1:]  # 车牌字符编号
        img = cv2.imread(os.path.join(self.plate_path, name))

        card_img = Gamma_trans(img, np.mean(img) * 1.5 / 255)
        gray_img = cv2.cvtColor(card_img, cv2.COLOR_BGR2GRAY)

        # 图片旋转
        angle = self.get_minAreaRect(gray_img)[-1]
        if angle > 0 and angle < 45:
            gray_img = self.rotate_bound(gray_img, angle)

        ret, gray_img = cv2.threshold(gray_img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)  # 二值化图像
        # 横向
        x_histogram = np.count_nonzero(255 - gray_img, axis=1)  # 统计黑色像素点多少
        y_histogram = np.count_nonzero(255 - gray_img, axis=0)

        #     draw_bar(gray_img)  # 绘制频率直方图和图像组合图

        # 1 取出外框
        # 1.1 根据横向直方图取出上下白边
        m, n = gray_img.shape
        threshold_out = 0.1
        ind = np.abs(np.diff(x_histogram))
        if np.any(ind >= n * threshold_out):
            t1, t2 = np.where(ind >= n * threshold_out)[0][[0, -1]]  # 取出差分超过阈值的下标
            if ((t2-t1)/m > 0.5) and (t2-t1 != 0):  # 如果修改后的长度比原来的小了一半，则放弃
                gray_img = gray_img[t1:t2, :]
        # 1.2 根据水平方向直方图截取左右白边
        m, n = gray_img.shape  # 重新统计
        ind = np.abs(np.diff(y_histogram))
        if np.any(ind >= m * threshold_out):
            t1, t2 = np.where(ind >= m * threshold_out)[0][[0, -1]]  # 取出差分超过阈值的下标
            t1 = t1 if t1 < 0.1 * n else 0
            t2 = t2 if t2 > 0.9 * n else n + 1
            gray_img = gray_img[:, t1:t2]

        # 2 分割车牌
        m, n = gray_img.shape  # 重新统计
        if m == 0:
            return
        gap = int(n / 7) + 3  # 平均每个字符的距离
        threshold = 0.7
        t = 0  # 记录下一个字符开始的列数
        num = 0  # 记录切分的字符数量
        for h in range(6):
            temp_img = gray_img[:, t:t + gap]
            y_hist = np.count_nonzero(255 - temp_img, axis=0)  # 重新统计
            t2 = np.where(y_hist >= m * threshold)[0][-1] if sum(y_hist >= m * threshold) else 0  # 取出差分超过阈值的下标
            if (m!=0) and (t2/m > 0.3):
                #             show_gray(gray_img[:, t:t+t2])
                file_num = 1 if h == 0 else 2
                cv2.imwrite(os.path.join(self.char_save_path, f'{file_num}_{card_char[num]}_{num}_{time.time()}.jpg'),
                            gray_img[:, t:t + t2])  # 为避免名称重复，文件名称加上时间戳
                num += 1
                t += t2
        if num != 6:  # 前面规则切分的字符数量不足6个，则平均切分剩余部分
            p = np.linspace(t, n, 7 - num + 1, endpoint=True)
            for p1, p2 in zip(p[:-1], p[1:]):
                #             show_gray(gray_img[:, int(p1): int(p2)])
                file_num = 2
                cv2.imwrite(os.path.join(self.char_save_path, f'{file_num}_{card_char[num]}_{num}_{time.time()}.jpg'),
                            gray_img[:, int(p1): int(p2)+1])
                num += 1
        else:
            #         show_gray(gray_img[:, t:])
            file_num = 2
            cv2.imwrite(os.path.join(self.char_save_path, f'{file_num}_{card_char[num]}_{num}_{time.time()}.jpg'),
                        gray_img[:, t:])


#%%
if __name__ == '__main__':
    CC = charser_cut()
    pic_files = os.listdir(CC.plate_path)
    for k in range(len(pic_files)):
        CC.plate_seg(pic_files[k])
