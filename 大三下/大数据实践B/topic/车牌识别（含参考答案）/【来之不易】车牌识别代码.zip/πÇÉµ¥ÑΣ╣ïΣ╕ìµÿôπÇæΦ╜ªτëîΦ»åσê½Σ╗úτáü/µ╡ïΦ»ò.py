import cv2  # pip install opencv-python
import tensorflow as tf
import os
from myfun import draw_RGB_hist, Gamma_trans

print(tf.__version__)
print(cv2.__version__)

# 读取图片
file_path = './data'
file_name = '0034-0_1-270&523_365&553-364&553_270&553_271&523_365&523-0_0_10_23_24_32_33-90-17.jpg'
img = cv2.imread(os.path.join(file_path, file_name))
# cv2.imshow('orginal', img)
# cv2.waitKey(0)

# draw_RGB_hist(img)
img_gamma = Gamma_trans(img, 0.7)  # Gamma变换：图像增强
# draw_RGB_hist(img_gamma)

# cv2.imshow('orginal', img_gamma)
# cv2.waitKey(0)

# 高斯平滑：降噪
img_gauss = cv2.GaussianBlur(img_gamma, (3, 3), 0, 0)
# cv2.imshow('orginal', img_gauss)
# cv2.waitKey(0)

# 灰度处理
gray = cv2.cvtColor(img_gauss, cv2.COLOR_BGR2GRAY)
# cv2.imshow('orginal', gray)
# cv2.waitKey(0)

# Sobel算子
sobel_x = cv2.Sobel(gray, cv2.CV_16S, 1, 0)
sobel_y = cv2.Sobel(gray, cv2.CV_16S, 0, 1)
absx = cv2.convertScaleAbs(sobel_x)
absy = cv2.convertScaleAbs(sobel_y)
img_sobel = cv2.addWeighted(absx, 0.5, absy, 0.5, 0)
import numpy as np
# cv2.imshow('orginal', np.concatenate((absx, absy), axis=1))
# cv2.waitKey(0)
# cv2.imshow('orginal', img_sobel)
# cv2.waitKey(0)

# 二值化
ret, bi_img = cv2.threshold(img_sobel, 0, 255, cv2.THRESH_OTSU)
# cv2.imshow('orginal', bi_img)
# cv2.waitKey(0)

# 形态学操作
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (17, 5))
img_top = cv2.morphologyEx(bi_img, cv2.MORPH_TOPHAT, kernel)
# cv2.imshow('orginal', np.concatenate((bi_img, img_top), axis=1))
# cv2.waitKey(0)
kernelx = cv2.getStructuringElement(cv2.MORPH_RECT, (20, 1))
kernely = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 15))
img_d1 = cv2.dilate(img_top, kernelx)  # 膨胀
img_e1 = cv2.erode(img_d1, kernelx)  # 腐蚀
img_e2 = cv2.erode(img_e1, kernely)  # 腐蚀
img_d2 = cv2.dilate(img_e2, kernelx)  # 膨胀
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (8, 6))
img_e3 = cv2.erode(img_e1, kernel, 20)

# cv2.imshow('orginal', np.concatenate((img_d1, img_e3), axis=1))
# cv2.waitKey(0)

# 中值滤波
img_median = cv2.medianBlur(img_e3, 21)
# cv2.imshow('orginal', img_median)
# cv2.waitKey(0)

try:
    contours, w1 = cv2.findContours(img_median, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
except ValueError:
    imgc, contours, w1 = cv2.findContours(img_median, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# img_copy = img_gauss.copy()
# img_draw = cv2.drawContours(img_copy, contours, -1, (0, 0, 255), 3)
# cv2.imshow('orginal', img_draw)
# cv2.waitKey(0)

from myfun import fix_angle, get_lab
card_imgs = fix_angle(contours, img_gauss)
save_path = './temp'
k = 0
for card_img in card_imgs:
    # cv2.imshow('card', card_img)
    # cv2.waitKey(0)
    h, w, _ = card_img.shape
    if w > 50 and h > 20 and get_lab(card_img):
        # cv2.imshow('card', card_img)
        # cv2.waitKey(0)
        k += 1
        cv2.imwrite(os.path.join(save_path, f'{file_name.split("-")[4]}-{k}.jpg'))

### ======================================================
import cv2
import os

plate_path = './temp'
card_img = cv2.imread(os.path.join(plate_path, '1_0_0_10_23_24_32_33_1595086011.6981094.jpg'))
# cv2.imshow('image', card_img)
# cv2.waitKey(0)

# from myfun import draw_hist
# draw_hist(card_img)








