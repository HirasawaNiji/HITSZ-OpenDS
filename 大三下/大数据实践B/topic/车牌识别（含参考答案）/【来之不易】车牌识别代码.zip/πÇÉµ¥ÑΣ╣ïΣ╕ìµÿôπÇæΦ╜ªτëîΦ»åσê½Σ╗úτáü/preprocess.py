# %% 加载库
import numpy as np
import os
import cv2
from myfun import draw_RGB_hist, get_lab, Gamma_trans, fix_angle

class plate_detected():
    def __init__(self):
        self.file_path = './data'
        self.file_names = os.listdir(self.file_path)
        self.img_save_path = './temp/'
        # self.SZ = 20          # 训练图片长宽
        # self.MAX_WIDTH = 1000  # 原始图片最大宽度
        # self.Min_Area = 2000  # 车牌区域允许最大面积
        # self.PROVINCE_START = 1000

    def read(self, file_name):
        '''
        :param file_name: 需要读取的图片的名称（在file_path下的图片）
        :return:
        '''
        img = cv2.imread(os.path.join(self.file_path, file_name))
        char_set = file_name.split('-')[4].split('_')  # 车牌字符
        return img, char_set

    def process(self, img):
        # 对图片进行Gamma转换
        img_correct = Gamma_trans(img, 0.7)  # np.mean(img) * 1.5 / 255
        # draw_RGB_hist(img_correct)  # 查看图片的3D直方图

        image = cv2.GaussianBlur(img_correct, (3, 3), 0, 0)  # 高斯平滑
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # 转灰度图

        # Sobel算子
        Sobel_x = cv2.Sobel(gray, cv2.CV_16S, 1, 0)
        Sobel_y = cv2.Sobel(gray, cv2.CV_16S, 0, 1)
        absX = cv2.convertScaleAbs(Sobel_x)  # 转回uint8
        absY = cv2.convertScaleAbs(Sobel_y)
        absX = cv2.addWeighted(absX, 0.5, absY, 0.5, 0)  # 转回uint8

        # 图像二值化
        ret, bi_image = cv2.threshold(absX, 0, 255, cv2.THRESH_OTSU)

        # 顶帽操作
        kernelX = cv2.getStructuringElement(cv2.MORPH_RECT, (17, 5))  # 17*5的矩形核
        image_TOPHAT = cv2.morphologyEx(bi_image, cv2.MORPH_TOPHAT, kernelX)  # cv2.MORPH_BLACKHAT

        # 膨胀腐蚀
        kernelX = cv2.getStructuringElement(cv2.MORPH_RECT, (20, 1))
        kernelY = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 15))
        image_d1 = cv2.dilate(image_TOPHAT, kernelX)  # 膨胀
        image_e1 = cv2.erode(image_d1, kernelX)  # 腐蚀
        image_e2 = cv2.erode(image_e1, kernelY)  # 腐蚀
        image_d2 = cv2.dilate(image_e2, kernelY)  # 膨胀
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (8, 6))
        image_d2 = cv2.erode(image_d2, kernel, 20)  # 腐蚀 车牌和车标、车灯等很容易粘连，所以多次腐蚀

        # 中值滤波
        image_median = cv2.medianBlur(image_d2, 21)
        return image, image_median

    def findContours(self, img, image_median):
        # 查找轮廓
        # cv2.findContours()函数接受的参数为二值图，即黑白的（不是灰度图），所以读取的图像要先转成灰度的，再转成二值图
        # 查找图像边缘整体形成的矩形区域，可能有很多，车牌就在其中一个矩形区域中
        # cv2.findContours()函数来查找检测物体的轮廓
        try:  # OpenCV版本不同，运行可能有错，故设计两种函数返回结果
            contours, w1 = cv2.findContours(image_median, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        except ValueError:
            img_c, contours, w1 = cv2.findContours(image_median, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # 绘制轮廓
        img_copy = img.copy()
        cv2.drawContours(img_copy, contours, -1, (0, 0, 255), 3)
        return contours

    def findPlate(self, img, char_set, contours):
        import time
        card_imgs = fix_angle(contours, img)
        k = 0
        for j in card_imgs:
            h, w, _ = j.shape
            if w > 50 and h > 20 and get_lab(j):
                k += 1
                cv2.imwrite(
                    os.path.join(self.img_save_path, f'{k}_{"_".join(char_set)}_{time.time()}.jpg'),
                    j
                )

    def detect(self, file_name):
        img, char_set = self.read(file_name)
        image, image_median = self.process(img)
        contours = self.findContours(img, image_median)
        self.findPlate(img, char_set, contours)

#%%
if __name__=='__main__':
    PD = plate_detected()
    for i in range(174):
        PD.detect(PD.file_names[i])


