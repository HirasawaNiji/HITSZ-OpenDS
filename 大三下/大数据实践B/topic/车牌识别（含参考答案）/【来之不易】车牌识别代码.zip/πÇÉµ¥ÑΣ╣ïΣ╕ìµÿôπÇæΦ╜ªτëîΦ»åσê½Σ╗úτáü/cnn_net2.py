import tensorflow as tf
from sklearn.model_selection import train_test_split
import numpy as np
import os
# from getimgdata import GetImgData

class CnnNet:
    def __init__(self, output_size, size=16, rate=0.5, filename='cnn_model.h5'):
        self.size = size  # 图像大小
        self.output_size = output_size  # 输出神经元个数
        self.rate = rate  # dropout丢失率
        self.filename = filename

    def cnnLayer(self):
        '''CNN网络结构'''
        # 模型
        model = tf.keras.Sequential()  # 实例化一个Sequential，接下来就可以使用add方法来叠加所需的网络层

        # 添加一个二维卷积层，输出数据维度为32，卷积核维度为3*3。输入数据维度为[16, 16, 1]，这里的维度是WHC格式，
        # 意思是输入图像像素为16*16的尺寸，使用1通道的图像。
        model.add(tf.keras.layers.Conv2D(32, (3, 3), kernel_initializer='he_normal', strides=1, padding='same',
                                         activation='relu', input_shape=[self.size, self.size, 1], name='conv1'))

        # 添加一个二维池化层，使用最大值池化，池化维度为2*2
        model.add(tf.keras.layers.MaxPool2D((2, 2), strides=2, padding='same', name='pool1'))
        model.add(tf.keras.layers.Dropout(rate=self.rate, name="d1"))
        model.add(tf.keras.layers.BatchNormalization())  # 批量标准化

        # 添加第二个卷积层
        model.add(tf.keras.layers.Conv2D(64, (3, 3), kernel_initializer='he_normal', strides=1, padding='same',
                                         activation='relu', name='conv2'))
        # 添加第二个池化层
        model.add(tf.keras.layers.MaxPool2D((2, 2), strides=2, padding='same', name='pool2'))
        model.add(tf.keras.layers.Dropout(rate=self.rate, name="d2"))
        model.add(tf.keras.layers.BatchNormalization())

        # 添加全连接的深度神经网络
        model.add(tf.keras.layers.Flatten(name='flatten'))  # 展开
        model.add(tf.keras.layers.Dense(128, activation='relu', kernel_initializer='he_normal'))

        model.add(tf.keras.layers.Dropout(self.rate))

        model.add(tf.keras.layers.Dense(self.output_size, activation='softmax', kernel_initializer='he_normal'))

        model.compile(loss='categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(), metrics=['accuracy'])
        model.summary()
        return model

    def cnnTrain(self, x_train, y_train, part, retrain=True):
        '''
        依据训练样本的模型输出与样本实际值进行模型训练
        :param x_train:
        :param y_train:
        :param retrain: 是否重新训练模型
        :return:
        '''
        if retrain:  # 重新训练
            model = self.cnnLayer()
            y_train2 = tf.one_hot(y_train, self.output_size)
            model.fit(x_train, y_train2, batch_size=100, verbose=2, epochs=500, validation_split=0.2)  #模型训练
            model.save(f'{part}_'+self.filename)
        else:  # 加载已经训练好的模型
            if not os.path.exists(f'{part}_'+self.filename):
                print(f'文件{part}_{self.filename}不存在，请确认！')

    def predict(self, x_test, part):
        '''
        预测函数，导入已训练好的模型后再将新样本数据放入，进行模型预测
        :param x_test: 测试样本的自变量
        :return:
        pro: 样本属于各类别的概率，形如：[[0.1, 0.1, 0.0, 0.0, 0.0, 0.8]]
        pre: 预测结果（数字标签：0,1,2,3,4,5,...）
        '''
        if not os.path.exists(f'{part}_'+self.filename):
            print(f'文件{part}_{self.filename}不存在，请确认！')
        else:
            pre_model = tf.keras.models.load_model(f'{part}_'+self.filename)
            pro = pre_model.predict(x_test)
            pre = np.argmax(pro, axis=1)
            return pro, pre

if __name__ == '__main__':
    from myfun import get_img_lab
    from sklearn.model_selection import train_test_split

    imgs, labels, num2str = get_img_lab('./cut_char')

    for part in [1, 2]:
        # part = 2
        cnn = CnnNet(output_size=len(num2str[part]))

        # 划分训练集与测试集
        x_train, x_test, y_train, y_test = train_test_split(imgs[part], labels[part], test_size=0.2, random_state=123)
        print(x_train.shape)
        print(y_train.shape)

        cnn.cnnTrain(x_train, y_train, part)
        y_pre, y_pre_lab = cnn.predict(x_test, part)
        import numpy as np

        print('模型正确率：', np.mean(y_pre_lab == y_test))
