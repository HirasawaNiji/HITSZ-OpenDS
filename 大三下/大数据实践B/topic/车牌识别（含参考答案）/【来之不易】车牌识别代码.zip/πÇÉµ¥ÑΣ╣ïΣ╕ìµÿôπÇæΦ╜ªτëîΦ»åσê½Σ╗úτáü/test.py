import cv2
import tensorflow as tf
import os
import shutil
import numpy as np
from cnn_net2 import CnnNet
from myfun import get_img_lab
from preprocess import plate_detected
from plate_seg import charser_cut


class plate_detect():
    def __init__(self):   #%% 模型参数设置
        self.provinces = ["皖", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑", "苏", "浙", "京", "闽", "赣",
                          "鲁", "豫", "鄂", "湘", "粤", "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁",
                          "新", "警", "学", "O"]
        self.ads = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M',
                    'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

    def predict(self, img_path):
        img_name = os.path.basename(img_path)
        img = cv2.imread(img_path)
        file_path = './test/char'  # 裁剪后字符图片保存的位置
        plate_path = './test'  # 裁剪的车牌图片存储位置
        shutil.rmtree(file_path)  # 删除文件夹
        os.makedirs(file_path)  # 新建空白文件夹

        #%% 车牌检测并保存
        char_set = img_name.split('-')[4].split("_")  # 车牌字符
        PD = plate_detected()
        PD.img_save_path = plate_path  # 裁剪的车牌图片存储位置
        image, image_median = PD.process(img)
        contours = PD.findContours(img, image_median)
        PD.findPlate(img, char_set, contours)

        #%% 字符裁剪
        CC = charser_cut()
        CC.plate_path = plate_path  # 裁剪的车牌图片存储位置
        CC.char_save_path = file_path  # 裁剪后字符图片保存的位置
        all_file_names = [i for i in os.listdir(CC.plate_path) if os.path.isfile(os.path.join(CC.plate_path, i))]  # 列出目录的下所有文件和文件夹保存到all_file_names
        all_file_names.sort(key=lambda fn: os.path.getmtime(CC.plate_path + "/" + fn))  # 按时间排序
        CC.plate_seg(all_file_names[-1])

        #%% 数据读取
        imgs, labels, num2str = get_img_lab(file_path)

        # 模型预测
        res = ''
        for part in [1, 2]:
            # 取出训练好的卷积模型
            cnn = CnnNet(output_size=len(num2str[part]))
            y_pre, y_pre_lab = cnn.predict(imgs[part], part)
            res = res + ''.join([num2str[part][i] for i in y_pre_lab])

        print(f'车牌识别结果：{res}')
        return img, res

#%%
if __name__ == '__main__':
    import matplotlib.pyplot as plt
    model = plate_detect()
    img, res = model.predict(
        './data/0034-0_1-270&523_365&553-364&553_270&553_271&523_365&523-0_0_10_23_24_32_33-90-17.jpg'
    )
    # for i in os.listdir('./data')[:10]:
    #     img, res = model.predict(os.path.join('./data', i))
    #     plt.imshow(img[:, :, [2, 1, 0]])
    #     plt.show()
