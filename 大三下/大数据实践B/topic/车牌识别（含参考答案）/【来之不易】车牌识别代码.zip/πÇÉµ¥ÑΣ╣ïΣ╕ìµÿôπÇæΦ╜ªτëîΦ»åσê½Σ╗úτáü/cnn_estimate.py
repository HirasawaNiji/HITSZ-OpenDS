import cv2
import os
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

# 1 批量读取车牌图片，以及对应标签====>自定义函数
path = ['./train_plate_data/plate', './train_plate_data/else']
files = [os.path.join(path[0], i) for i in os.listdir(path[0])] + [os.path.join(path[1], i) for i in os.listdir(path[1])]
labs = [1]*len(os.listdir(path[0])) + [0]*len(os.listdir(path[1]))  # 标签

data = []
dim = (20, 20)
for f in files:
    img = cv2.imread(f)
    img2 = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
    data.append(img2)
data = np.array(data)
labs = np.array(labs)
print(data.shape)
print(labs.shape)

# 2 模型构建
input_size = (20, 20, 3)
model = tf.keras.Sequential()
model.add(tf.keras.layers.Conv2D(
    filters=32, kernel_size=(3, 3), input_shape=input_size, strides=1, padding='same', activation='relu'
))
model.add(tf.keras.layers.MaxPool2D(
    strides=2, pool_size=(2, 2),
))
model.add(tf.keras.layers.BatchNormalization())
model.add(tf.keras.layers.Conv2D(
    filters=64, kernel_size=(3, 3), strides=1, padding='same', activation='relu'
))
model.add(tf.keras.layers.MaxPool2D(
    strides=2, pool_size=(2, 2)
))
model.add(tf.keras.layers.BatchNormalization())
model.add(tf.keras.layers.Flatten())
model.add(tf.keras.layers.Dense(512, activation='relu'))
# 分类层
model.add(tf.keras.layers.Dense(2, activation='softmax'))
model.compile(
    optimizer=tf.keras.optimizers.Adam(),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)
model.summary()


# 3 模型测试
history = model.fit(data, tf.one_hot(labs, 2), batch_size=64, epochs=20, validation_split=0.1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.legend(['training', 'valivation'], loc='upper left')
plt.show()

# 4 模型保存
model.save('./plate_estimate.h5')

# 5 模型调用
new_model = tf.keras.models.load_model('./plate_estimate.h5')
y_pre_prob = new_model.predict(data)
print(np.argmax(y_pre_prob, axis=1))

