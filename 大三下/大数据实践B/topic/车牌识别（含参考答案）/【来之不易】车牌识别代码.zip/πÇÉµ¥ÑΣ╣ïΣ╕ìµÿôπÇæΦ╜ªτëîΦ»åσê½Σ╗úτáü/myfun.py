#%%
import numpy as np
import re
from PIL import Image
import cv2
import random
import tensorflow as tf
import os
import matplotlib.pyplot as plt

#%% 把彩色图像转为灰度图像（色彩对识别没有什么用）
def convert2gray(img):
    if len(img.shape) > 2:
        gray = np.mean(img, -1)
        return gray
    else:
        return img

#%% 读取num个训练数据
def get_train_data(path, num = 10000):
    '''
    生成训练数据
    '''
    x_data = []
    y_data = []
    filenames = [re.search('.*?\.jpg', i).group() for i in os.listdir(path)]
    samp = random.sample(range(len(filenames)), num)
    for i in samp:
        roisize = filenames[i].split('-')[2]
        N1, N2, M1, M2 = re.split('[&_]', roisize)
        image = Image.open(path+'/'+filenames[i])
        car_num_cut = image.crop((int(N1), int(N2), int(M1), int(M2)))
        car_num_cut = car_num_cut.resize((80, 40))
        image_np = np.array(car_num_cut)
#         image_np = convert2gray(image_np)
        image_np = convert2gray(image_np)
        image_np = image_np.reshape((40, 80, 1))/255
        assert image_np.shape == (40, 80, 1)
        label = []
        label.append(int(filenames[i].split('-')[4].split('_')[0]))
        for j in filenames[i].split('-')[4].split('_')[1:]:
            label.append(int(j))
        x_data.append(image_np)
        y_data.append(np.array(label).astype(np.int32))
    names = [filenames[n] for n in samp]
    x_data = np.array(x_data).astype(np.float)
    y_data = np.array(y_data)
    return x_data, y_data, names

# %% 绘制RGB像素分布的3D柱状图
def draw_RGB_hist(img):
    '''
    直方图分析RBG像素中值分布情况，如果直方图分布过分靠近0或者255，可能出现暗部细节不足或者亮部细节丢失的情况。
    :param img:
    :return:
    '''
    # 分通道计算每个通道的直方图
    hist_b = cv2.calcHist([img], [0], None, [256], [0, 255])
    hist_g = cv2.calcHist([img], [1], None, [256], [0, 255])
    hist_r = cv2.calcHist([img], [2], None, [256], [0, 255])

    # 可视化
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    for c, z, Hist in zip(list('bgr'), [20, 10, 0], [hist_b, hist_g, hist_r]):
        cs = [c] * 256
        ax.bar(range(256), Hist.ravel(), zs=z, zdir='y', color=cs, alpha=0.618, edgecolor='none', lw=0)
    plt.show()

# %% 自定义函数实现矫正像素值分布
def Gamma_trans(img, gamma):
    '''
    Gamma变换：通过非线性变换，让图像从对曝光强度的线性相应变得更接近人眼感受到的响应。
    先归一化到1，然后gamma作为指数值求出新的像素值再进行还原
    :param img: 图片的3通道像素矩阵，ndarray
    :param gamma: 调节指数，小于1的值让暗部细节大量提升，同时亮部细节少量提升
    :return: 提升后的3通道像素矩阵，ndarray
    '''
    gamma_table = [np.power(x / 255.0, gamma) * 255.0 for x in range(256)]
    gamma_table = np.round(np.array(gamma_table)).astype(np.uint8)
    return cv2.LUT(img, gamma_table)


# %%  图片处理过程可视化
def draw_all_pic(img, img_correct, image, gray, absX, bi_image, image_TOPHAT, image_d2, image_median):
    plt.rcParams['axes.titlesize'] = 'medium'
    plt.rcParams['font.sans-serif'] = 'SimHei'  # 正常显示中文
    plt.subplot(3, 3, 1)
    plt.imshow(img[:, :, [2, 1, 0]])
    plt.title('原图')

    plt.subplot(3, 3, 2)
    plt.imshow(img_correct[:, :, [2, 1, 0]])
    plt.title('Gamma变化')

    plt.subplot(3, 3, 3)
    plt.imshow(image[:, :, [2, 1, 0]])
    plt.title('Gaussian平滑')

    plt.subplot(3, 3, 4)
    plt.imshow(gray, cmap='gray')
    plt.title('灰度图')

    plt.subplot(3, 3, 5)
    plt.imshow(absX, cmap='gray')
    plt.title('Sobel算子')

    plt.subplot(3, 3, 6)
    plt.imshow(bi_image, cmap='gray')
    plt.title('二值化')

    plt.subplot(3, 3, 7)
    plt.imshow(image_TOPHAT, cmap='gray')
    plt.title('顶帽操作')

    plt.subplot(3, 3, 8)
    plt.imshow(image_d2, cmap='gray')
    plt.title('膨胀腐蚀')

    plt.subplot(3, 3, 9)
    plt.imshow(image_median, cmap='gray')
    plt.title('中值滤波')
    plt.savefig(f'./t.jpg', dpi=1200)
    plt.show()

# %% 自定义调用函数：获取
def get_lab(img, dim = (20, 20)):
    img2 = cv2.resize(img, dim, interpolation=cv2.INTER_AREA)

    ckpt = './plate_estimate.h5'  # 模型保存位置
    new_model = tf.keras.models.load_model(ckpt)
    pre = new_model.predict(img2.reshape((1, 20, 20, 3)))  # 网络预测值

    return np.argmax(pre[0]) == 1
# img = cv2.imread('./train_plate_data/plate/44_1656_163.20.jpg')
# print(get_lab(img))
#%%  车牌位置限制
def point_limit(point):
    if point[0] < 0:
        point[0] = 0
    if point[1] < 0:
        point[1] = 0
    return point

def accurate_place(card_img_hsv, limit1, limit2, color,cfg):
    row_num, col_num = card_img_hsv.shape[:2]
    xl = col_num
    xr = 0
    yh = 0
    yl = row_num
    #col_num_limit = cfg["col_num_limit"]
    row_num_limit = cfg["row_num_limit"]
    col_num_limit = col_num * 0.8 if color != "green" else col_num * 0.5 # 绿色有渐变
    for i in range(row_num):
        count = 0
        for j in range(col_num):
            H = card_img_hsv.item(i, j, 0)
            S = card_img_hsv.item(i, j, 1)
            V = card_img_hsv.item(i, j, 2)
            if limit1 < H <= limit2 and 34 < S and 46 < V:
                count += 1
        if count > col_num_limit:
            if yl > i:
                yl = i
            if yh < i:
                yh = i
    for j in range(col_num):
        count = 0
        for i in range(row_num):
            H = card_img_hsv.item(i, j, 0)
            S = card_img_hsv.item(i, j, 1)
            V = card_img_hsv.item(i, j, 2)
            if limit1 < H <= limit2 and 34 < S and 46 < V:
                count += 1
        if count > row_num - row_num_limit:
            if xl > j:
                xl = j
            if xr < j:
                xr = j
    return xl, xr, yh, yl

#%% 纠正角度
def fix_angle(contours, img):
    '''
    :param contours: 找到的轮廓矩阵
    :param img: 原来的图片
    :return:  纠正角度后的轮廓矩阵
    '''
    # 一一排除不是车牌的矩形区域，找到最小外接矩形的长宽比复合车牌条件的边缘检测到的物体
    car_contours = []
    for cnt in contours:
        rect = cv2.minAreaRect(cnt)
        # 生成最小外接矩形，点集 cnt 存放的就是该四边形的4个顶点坐标（点集里面有4个点）
        # 函数 cv2.minAreaRect() 返回一个Box2D结构rect：（最小外接矩形的中心（x，y），（宽度，高度），旋转角度），
        # 但是要绘制这个矩形，我们需要矩形的4个顶点坐标box, 通过函数 cv2.boxPoints() 获得，
        # 返回形式[ [x0,y0], [x1,y1], [x2,y2], [x3,y3] ]。

        # 得到的最小外接矩形的4个顶点顺序、中心坐标、宽度、高度、旋转角度（是度数形式，不是弧度数）
        if 0 in rect[1]:
            pass
        else:
            area_width, area_height = rect[1]
            if area_width < area_height:
                area_width, area_height = area_height, area_width
            wh_ratio = area_width / area_height
            # 要求矩形区域长宽比在2到5.5之间，2到5.5是车牌的长宽比，其余的矩形排除 一般的比例是3.5
            if wh_ratio > 2 and wh_ratio < 5.5:  #
                car_contours.append(rect)
                box = cv2.boxPoints(rect)
                box = np.int0(box)

    card_imgs = []
    pic_hight, pic_width = img.shape[:2]
    oldimg = img.copy()
    # 矩形区域可能是倾斜的矩形，需要矫正，以便使用颜色定位
    # 这个就是为什么我们不选择YOLO,SSD或其他的目标检测算法来检测车牌号的原因！！！
    for rect in car_contours:
        if rect[2] > -1 and rect[2] < 1:  # 创造角度，使得左、高、右、低拿到正确的值
            angle = 1
        else:
            angle = rect[2]
        rect = (rect[0], (rect[1][0] + 5, rect[1][1] + 5), angle)  # 扩大rect范围，避免车牌边缘被排除

        box = cv2.boxPoints(rect)
        # 避免边界超出图像边界
        heigth_point = right_point = [0, 0]
        left_point = low_point = [pic_width, pic_hight]
        for point in box:
            if left_point[0] > point[0]:
                left_point = point
            if low_point[1] > point[1]:
                low_point = point
            if heigth_point[1] < point[1]:
                heigth_point = point
            if right_point[0] < point[0]:
                right_point = point

        if left_point[1] <= right_point[1]:  # 正角度
            new_right_point = [right_point[0], heigth_point[1]]
            pts2 = np.float32([left_point, heigth_point, new_right_point])  # 字符只是高度需要改变
            pts1 = np.float32([left_point, heigth_point, right_point])
            M = cv2.getAffineTransform(pts1, pts2)  # 仿射变换
            dst = cv2.warpAffine(oldimg, M, (pic_width, pic_hight))
            new_right_point = point_limit(new_right_point)
            heigth_point = point_limit(heigth_point)
            left_point = point_limit(left_point)
            card_img = dst[int(left_point[1]):int(heigth_point[1]), int(left_point[0]):int(new_right_point[0])]
            height, width, _ = card_img.shape
            if 10 < height < width and width > 20 and 0 not in card_img.shape:
                card_imgs.append(card_img)

        elif left_point[1] > right_point[1]:  # 负角度

            new_left_point = [left_point[0], heigth_point[1]]
            pts2 = np.float32([new_left_point, heigth_point, right_point])  # 字符只是高度需要改变
            pts1 = np.float32([left_point, heigth_point, right_point])
            M = cv2.getAffineTransform(pts1, pts2)
            dst = cv2.warpAffine(oldimg, M, (pic_width, pic_hight))
            point_limit(right_point)
            point_limit(heigth_point)
            point_limit(new_left_point)
            card_img = dst[int(right_point[1]):int(heigth_point[1]), int(new_left_point[0]):int(right_point[0])]
            height, width, _ = card_img.shape
            if 10 < height < width and width > 20 and 0 not in card_img.shape:
                card_imgs.append(card_img)

    # 开始使用颜色定位，排除不是车牌的矩形，目前只识别蓝、绿、黄车牌

    colors = []
    for card_index, card_img in enumerate(card_imgs):
        green = yello = blue = black = white = 0
        card_img_hsv = cv2.cvtColor(card_img, cv2.COLOR_BGR2HSV)
        # 有转换失败的可能，原因来自于上面矫正矩形出错
        if card_img_hsv is None:
            continue
        row_num, col_num = card_img_hsv.shape[:2]
        card_img_count = row_num * col_num

        for i in range(row_num):
            for j in range(col_num):
                H = card_img_hsv.item(i, j, 0)
                S = card_img_hsv.item(i, j, 1)
                V = card_img_hsv.item(i, j, 2)
                if 11 < H <= 34 and S > 34:  # 图片分辨率调整
                    yello += 1
                elif 35 < H <= 99 and S > 34:  # 图片分辨率调整
                    green += 1
                elif 99 < H <= 124 and S > 34:  # 图片分辨率调整
                    blue += 1

                if 0 < H < 180 and 0 < S < 255 and 0 < V < 46:
                    black += 1
                elif 0 < H < 180 and 0 < S < 43 and 221 < V < 225:
                    white += 1
        color = "no"

        limit1 = limit2 = 0
        if yello * 2 >= card_img_count:
            color = "yello"
            limit1 = 11
            limit2 = 34  # 有的图片有色偏偏绿
        elif green * 2 >= card_img_count:
            color = "green"
            limit1 = 35
            limit2 = 99
        elif blue * 2 >= card_img_count:
            color = "blue"
            limit1 = 100
            limit2 = 124  # 有的图片有色偏偏紫
        elif black + white >= card_img_count * 0.7:  # TODO
            color = "bw"
        colors.append(color)
        if limit1 == 0:
            continue

        cfg = {"open":1, "blur":3, "morphologyr":4, "morphologyc":19, "col_num_limit":10, "row_num_limit":21}

        # 以下为根据车牌颜色再定位，缩小边缘非车牌边界
        xl, xr, yh, yl = accurate_place(card_img_hsv, limit1, limit2, color, cfg)
        if yl == yh and xl == xr:
            continue
        need_accurate = False
        if yl >= yh:
            yl = 0
            yh = row_num
            need_accurate = True
        if xl >= xr:
            xl = 0
            xr = col_num
            need_accurate = True
        card_imgs[card_index] = card_img[yl:yh, xl:xr] if color != "green" or yl < (yh - yl) // 4 else card_img[yl - (
                    yh - yl) // 4:yh, xl:xr]
        if need_accurate:  # 可能x或y方向未缩小，需要再试一次
            card_img = card_imgs[card_index]
            card_img_hsv = cv2.cvtColor(card_img, cv2.COLOR_BGR2HSV)
            xl, xr, yh, yl = accurate_place(card_img_hsv, limit1, limit2, color, cfg)
            if yl == yh and xl == xr:
                continue
            if yl >= yh:
                yl = 0
                yh = row_num
            if xl >= xr:
                xl = 0
                xr = col_num
        card_imgs[card_index] = card_img[yl:yh, xl:xr] if color != "green" or yl < (yh - yl) // 4 else card_img[yl - (
                    yh - yl) // 4:yh, xl:xr]
    return card_imgs


def get_img_lab(file_path):
    '''
    获取指定路径下的图片和标签数据
    :param file_path: 图片储存的位置（字符分割后的图片储存位置）
    :return: imgs：ndarray，归一化后的图片像素数据 [size, height, width, channel_size]
    labels：图片对应的数字标签
    num2str：数字标签与对应的字符
    '''
    # file_path = './cut_char/'
    file_names = os.listdir(file_path)
    provinces = ["皖", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑", "苏", "浙", "京", "闽", "赣",
                 "鲁", "豫", "鄂", "湘", "粤", "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁",
                 "新", "警", "学", "O"]
    ads = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M',
                'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'O']

    num2str = {1: {i: j for i, j in enumerate(provinces)},
               2: {i: j for i, j in enumerate(ads)}}
    imgs = {1: [], 2: []}  # 所有图片汇总
    labels = {1: [], 2: []}  # 所有标签汇总

    for f in file_names:
        img = cv2.imread(os.path.join(file_path, f))[:, :, 0:1]  # 读取图片(灰度图),并取其中一个通道的值，但请注意要保持其维度(三维)不变
        img = cv2.resize(img, (16, 16))
        if f[0] == '1':  # 省份图片集合
            imgs[1].append(img.reshape([16, 16, 1]))  # 图片数据
            labels[1].append(int(f.split('_')[1]))  # 标签数据
        else:  # 字母和数字的图片集合
            imgs[2].append(img.reshape([16, 16, 1]))  # 图片数据
            labels[2].append(int(f.split('_')[1]))  # 标签数据
    imgs[2] = np.array(imgs[2]) / 255
    imgs[1] = np.array(imgs[1]) / 255
    labels[2] = np.array(labels[2])
    labels[1] = np.array(labels[1])
    return imgs, labels, num2str