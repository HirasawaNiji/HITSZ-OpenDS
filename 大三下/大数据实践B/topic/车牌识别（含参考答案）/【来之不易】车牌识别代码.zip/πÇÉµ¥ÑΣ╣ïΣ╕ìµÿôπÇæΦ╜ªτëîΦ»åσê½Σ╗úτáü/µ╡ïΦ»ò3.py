from myfun import get_img_lab
from sklearn.model_selection import train_test_split
from cnn_net2 import CnnNet

imgs, labels, num2str = get_img_lab('./cut_char')

for part in [1, 2]:
    # part = 2
    cnn = CnnNet(output_size=len(num2str[part]))

    # 划分训练集与测试集
    x_train, x_test, y_train, y_test = train_test_split(imgs[part], labels[part], test_size=0.2, random_state=123)

    cnn.cnnTrain(x_train, y_train, part)
    y_pre, y_pre_lab = cnn.predict(x_test, part)
    import numpy as np

    print('模型正确率：', np.mean(y_pre_lab == y_test))
